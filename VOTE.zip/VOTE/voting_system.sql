-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2025 at 03:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voting_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(5, 'admin', '$2y$10$svvA7NO0xEoU1nqRJO/5J.KHKHSjs3Z50W82QR4DgdHGvEGxKwlye'),
(18, 'admin', '$2y$10$KA0cPkOYffvLQbJ5IWWOqe11kjOgkOfQE/e/QuksYQY0BU3pH7kyW');

-- --------------------------------------------------------

--
-- Table structure for table `participants`
--

CREATE TABLE `participants` (
  `participant_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `participants`
--

INSERT INTO `participants` (`participant_id`, `name`, `role`, `image`, `description`) VALUES
(22, 'KAGAME JOHN', 'GUILD PRESIDENT', 'A.jpeg', 'ACCOUNTING STUDENT'),
(23, 'MUGISHA JEROM', 'GUILD PRESIDENT', 'B.jpeg', 'IT STUDENT'),
(24, 'KWEZI NOAH ', 'GUILD PRESIDENT', 'C.jpeg', 'EDUCATION STUDENT'),
(25, 'UWASE MARRY ', 'MEMBER OF PARLIAMENT', 'D.jpeg', 'MP ACCOUNTING'),
(26, 'MUTONI JANE ', 'MEMBER OF PARLIAMENT', 'F.jpeg', 'MP EDUCATION'),
(27, 'MUBIRU PETER', 'MEMBER OF PARLIAMENT', 'G.jpeg', 'MP MANAGEMENT'),
(28, 'MUTEBI BEN', 'MEMBER OF PARLIAMENT', 'H.jpeg', 'MP IT'),
(29, 'GAKIGA JOSHUA', 'GENERAL SECRETARY', 'I.jpeg', 'IT STUDENT'),
(30, 'WINNIE VICTORIA', 'GENERAL SECRETARY', 'J.jpeg', 'ACCOUNTING STUDENT'),
(31, 'KAGWA JAMES', 'GENERAL SECRETARY', 'K.jpeg', 'JOURNALISM STUDENT');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `registration_number` varchar(50) NOT NULL,
  `voting_token` varchar(255) NOT NULL,
  `voting_link` varchar(255) NOT NULL,
  `token_used` tinyint(1) DEFAULT 0,
  `token_expiry` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `email`, `registration_number`, `voting_token`, `voting_link`, `token_used`, `token_expiry`, `created_at`) VALUES
(29, 'igisubizopats@gmail.com', '24/BIT/BU/R/1003', '569bab1f9b173d1b15d55feb71a71562', 'http://localhost/VOTE/user/vote.php?token=569bab1f9b173d1b15d55feb71a71562', 1, '2025-02-10 09:55:23', '2025-02-10 08:54:23'),
(30, 'shopper@gmail.com', '24/BIT/BU/R/1003', '9e624770de3fa39df56b05813515d4d6', 'http://localhost/VOTE/user/vote.php?token=9e624770de3fa39df56b05813515d4d6', 1, '2025-02-10 09:56:22', '2025-02-10 08:55:22'),
(31, 'pats@gmail.com', '24/BIT/BU/R/1003', 'b030a7cc25c7e545947a7d6e048d3d93', 'http://localhost/VOTE/user/vote.php?token=b030a7cc25c7e545947a7d6e048d3d93', 0, '2025-02-10 09:59:01', '2025-02-10 08:58:01'),
(32, 'igisubiz0@gmail.com', 'STU12345', '453f019db995a2a83d599b0ea042816c', 'http://localhost/VOTE/user/vote.php?token=453f019db995a2a83d599b0ea042816c', 1, '2025-02-10 10:03:58', '2025-02-10 09:02:58'),
(33, 'shoppr@gmail.com', '24/BIT/BU/R/1003', '8602cc5733d5cf040b6268121068266c', 'http://localhost/VOTE/user/vote.php?token=8602cc5733d5cf040b6268121068266c', 1, '2025-02-26 07:17:47', '2025-02-26 06:16:47'),
(34, 'igisubizopas@gmail.com', '24/BIT/BU/R/1003', 'b448848eb10b0f7b3368f8094314f818', 'http://localhost/VOTE/user/vote.php?token=b448848eb10b0f7b3368f8094314f818', 1, '2025-02-26 07:18:55', '2025-02-26 06:17:55');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `vote_id` int(11) NOT NULL,
  `registration_number` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `participant_id` int(11) NOT NULL,
  `vote_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`vote_id`, `registration_number`, `category`, `participant_id`, `vote_time`) VALUES
(27, '21/BCN/BU/R/1003', 'GUILD PRESIDENT', 2, '2025-02-04 15:54:59'),
(28, '24/BIT/BU/R/1003', 'GENERAL SECRETARY', 31, '2025-02-05 06:23:05'),
(29, '22/BSE/BU/R/1009', 'GENERAL SECRETARY', 31, '2025-02-05 06:23:52'),
(30, '24/BIT/BU/R/1003', 'GUILD PRESIDENT', 23, '2025-02-05 06:26:20'),
(31, '22/BSE/BU/R/1009', 'GUILD PRESIDENT', 24, '2025-02-05 09:05:06'),
(32, '24/BIT/BU/R/1003', 'MEMBER OF PARLIAMENT', 26, '2025-02-05 13:13:52'),
(33, '22/BSE/BU/R/1004', 'GUILD PRESIDENT', 23, '2025-02-06 09:06:25'),
(34, '22/BSE/BU/R/1004', 'MEMBER OF PARLIAMENT', 26, '2025-02-06 09:06:31'),
(35, '22/BSE/BU/R/1004', 'GENERAL SECRETARY', 30, '2025-02-06 09:06:44'),
(36, 'STU12345', 'GUILD PRESIDENT', 22, '2025-02-07 07:30:05'),
(37, '23/BSE/BU/R/1003', 'GENERAL SECRETARY', 29, '2025-02-07 07:30:42'),
(38, 'STU12345', 'MEMBER OF PARLIAMENT', 26, '2025-02-07 07:55:54'),
(39, 'STU12345', 'GENERAL SECRETARY', 30, '2025-02-07 07:55:59'),
(40, 'STU67890', 'GUILD PRESIDENT', 22, '2025-02-07 07:56:49'),
(41, 'STU67890', 'MEMBER OF PARLIAMENT', 26, '2025-02-07 07:56:53'),
(42, 'STU67890', 'GENERAL SECRETARY', 29, '2025-02-07 07:56:57'),
(43, '23/BSE/BU/R/1004', 'GUILD PRESIDENT', 23, '2025-02-07 09:20:41'),
(44, '23/BSE/BU/R/1004', 'MEMBER OF PARLIAMENT', 27, '2025-02-07 09:20:56'),
(45, '23/BSE/BU/R/1004', 'GENERAL SECRETARY', 30, '2025-02-07 09:21:08'),
(46, '19/BSE/BU/R/1003', 'GUILD PRESIDENT', 23, '2025-02-07 10:18:49'),
(47, '19/BSE/BU/R/1003', 'MEMBER OF PARLIAMENT', 26, '2025-02-07 10:19:01'),
(48, '19/BSE/BU/R/1003', 'GENERAL SECRETARY', 30, '2025-02-07 10:19:08');

-- --------------------------------------------------------

--
-- Table structure for table `voting_timer`
--

CREATE TABLE `voting_timer` (
  `id` int(11) NOT NULL,
  `end_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voting_timer`
--

INSERT INTO `voting_timer` (`id`, `end_time`) VALUES
(1, '2025-02-26 09:19:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `participants`
--
ALTER TABLE `participants`
  ADD PRIMARY KEY (`participant_id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`vote_id`),
  ADD UNIQUE KEY `registration_number` (`registration_number`,`category`);

--
-- Indexes for table `voting_timer`
--
ALTER TABLE `voting_timer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `participants`
--
ALTER TABLE `participants`
  MODIFY `participant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `vote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `voting_timer`
--
ALTER TABLE `voting_timer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
