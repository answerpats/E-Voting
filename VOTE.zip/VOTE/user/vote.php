<?php
session_start();
require_once '../database.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure token is provided for first-time access
if (!isset($_SESSION['token_valid'])) {
    if (!isset($_GET['token'])) {
        die("No voting token provided.");
    }

    $token = $_GET['token'];

    // Fetch the token details securely
    $query = "SELECT * FROM voters WHERE voting_token = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $voter = $result->fetch_assoc();

    if (!$voter) {
        die("This voting link is invalid.");
    }

    // Check if the token is already used
    if ($voter['token_used'] == 1) {
        die("This voting link has already been used.");
    }

    // Check if the token is expired
    $current_time = date("Y-m-d H:i:s");
    if ($current_time > $voter['token_expiry']) {
        die("This voting link has expired.");
    }

    // Store voter info in session
    $_SESSION['voter_id'] = $voter['email'];
    $_SESSION['registration_number'] = $voter['registration_number'];
    $_SESSION['token_valid'] = true;

    // Mark token as used to prevent reuse
    $update_query = "UPDATE voters SET token_used = 1 WHERE voting_token = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("s", $token);
    $stmt->execute();

    // Redirect to prevent resubmission of the token
    header("Location: vote.php");
    exit();
}

// Ensure user accessed the page with a valid session
if (!isset($_SESSION['token_valid']) || $_SESSION['token_valid'] !== true) {
    die("Unauthorized access! Please use a valid voting link.");
}

// Auto logout after inactivity (10 minutes)
if (!isset($_SESSION['last_activity'])) {
    $_SESSION['last_activity'] = time();
}

$inactive_time_limit = 10 * 60; // 10 minutes timeout
if (time() - $_SESSION['last_activity'] > $inactive_time_limit) {
    session_destroy();
    header("Location: expired.php");
    exit();
}

$_SESSION['last_activity'] = time(); // Reset last activity timer

$registration_number = $_SESSION['registration_number']; // Retrieve registration number from session

// Handle voting submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vote'])) {
    $participant_id = $_POST['participant_id'];
    $category = $_POST['category'];

    // Check if the user has already voted in this category
    $stmt = $conn->prepare("SELECT * FROM votes WHERE registration_number = ? AND category = ?");
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }
    $stmt->bind_param("ss", $registration_number, $category);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['message'] = "You have already voted in this category.";
    } else {
        // Record the vote
        $stmt = $conn->prepare("INSERT INTO votes (registration_number, category, participant_id) VALUES (?, ?, ?)");
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        $stmt->bind_param("ssi", $registration_number, $category, $participant_id);
        if ($stmt->execute()) {
            $_SESSION['message'] = "Your vote for $category has been recorded successfully!";
        } else {
            $_SESSION['message'] = "Failed to record your vote. Please try again.";
        }
    }

    // Redirect to avoid form resubmission
    header("Location: vote.php");
    exit();
}

// Fetch participants grouped by category
$categories = ['Guild President', 'Member of Parliament', 'General Secretary'];
$participants_by_category = [];

foreach ($categories as $category) {
    $stmt = $conn->prepare("SELECT participant_id, name, role, image, description FROM participants WHERE role = ?");
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $result = $stmt->get_result();
    $participants_by_category[$category] = $result->fetch_all(MYSQLI_ASSOC);
}

// Fetch the voting end time
$query = "SELECT end_time FROM voting_timer ORDER BY id DESC LIMIT 1";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$votingEndTime = $row['end_time'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Page</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
            margin: 15px;
            text-align: center;
        }
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .card img {
            max-width: 100%;
            height: 255px;
            border-radius: 8px 8px 0 0;
            object-fit: contain;
        }
        .card-body {
            padding: 15px;
        }
        .card-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .navbar {
    padding: 10px 0;
}

.navbar-brand img {
    border-radius: 5px;
}

.navbar-brand div {
    display: flex;
    flex-direction: column;
    align-items: start;
}

    </style>
</head>
<body>
<script>
    window.onload = function() {
        let endTimeString = "<?php echo $votingEndTime; ?>";
        console.log("End time:", endTimeString); // Debugging in browser console

        if (!endTimeString) {
            document.getElementById("countdown").innerHTML = "No voting time set.";
            return;
        }

        let endTime = new Date(endTimeString).getTime();
        let countdownElement = document.getElementById("countdown");
        let voteForm = document.getElementById("voteForm");
        let voteButton = document.getElementById("voteButton");

        function checkVotingEnd() {
            let now = new Date().getTime();
            let timeLeft = endTime - now;

            if (timeLeft <= 0) {
                clearInterval(timer);

                // Show popup
                Swal.fire({
                    icon: 'error',
                    title: 'Voting has ended!',
                    text: 'WAIT FOR THE RESULTS TO BE ANNOUNCED',
                    confirmButtonText: 'OK'
                });

                countdownElement.innerHTML = "❌ Voting Period is Over!";
                if (voteButton) voteButton.disabled = true; // Disable the vote button if it exists
                return;
            }
             
            let days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
            let hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

            countdownElement.innerHTML = `${days}D ${hours}H ${minutes}M ${seconds}S `;
        }

        let timer = setInterval(checkVotingEnd, 1000);

        if (voteForm) {
            voteForm.addEventListener("submit", function(event) {
                let now = new Date().getTime();
                if (now >= endTime) {
                    event.preventDefault(); // Prevent form submission
                    Swal.fire({
                        icon: 'error',
                        title: 'Voting has ended!',
                        text: 'WAIT FOR THE RESULTS TO BE ANNOUNCED',
                        confirmButtonText: 'OK'
                    });
                }
            });
        }

        // Check immediately on page load
        checkVotingEnd();
    };
</script>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container d-flex justify-content-center">
        <!-- Logo + Text -->
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="../image/logo.png" alt="Bugema University Logo" width="60" height="60" class="me-2" style="border-radius: 5px;">
            <div class="d-flex flex-column">
                <span class="fw-bold text-white fs-4">BUGEMA UNIVERSITY</span>
                <span class="small text-white fst-italic" style="font-size: 14px;">Excellence in Service</span>
            </div>
        </a>
    </div>

    <!-- Navbar Toggler for Mobile -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navigation Links -->
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
            <span class="navbar-text text-white me-3">
                <?php 
                if (isset($_SESSION['voter_id']) && isset($_SESSION['registration_number'])) {
                    echo " " . htmlspecialchars($_SESSION['voter_id']) . " | " . htmlspecialchars($_SESSION['registration_number']);
                } else {
                    echo 'Guest';
                }
                ?>
            </span>
            <li class="nav-item">
                <a class="nav-link active text-white" href="../login.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

  <!-- Voting Page Content -->
    <div class="container mt-5">
   <h2>🕒 Time Left to Vote:</h2>
<div id="countdown" style="font-size: 24px; font-weight: bold;"></div>


        <h1>Vote for Your Favorite Participant</h1>
      <formform id="voteForm" action="process_vote.php" method="POST">
        <div class="row">
            <?php foreach ($participants_by_category as $category => $participants): ?>
                <h3 class="text-center"><?php echo $category; ?></h3>
                <?php foreach ($participants as $participant): ?>
                    <div class="col-md-4">
                        <div class="card">
                            <img src="../admin/uploads/<?php echo $participant['image']; ?>" class="card-img-top" alt="<?php echo $participant['name']; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $participant['name']; ?></h5>
                                <p class="card-text"><?php echo $participant['description']; ?></p>
                                <p class="card-text"><?php echo $participant['role']; ?></p>                            
                                <form method="POST">
                                    <input type="hidden" name="participant_id" value="<?php echo $participant['participant_id']; ?>">
                                    <input type="hidden" name="category" value="<?php echo $participant['role']; ?>">
                                    <button type="submit" name="vote" class="btn btn-primary">Vote</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </div>
    </form>

    <!-- Success/Error Message Modal -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if (isset($_SESSION['message'])): ?>
                        <?php echo $_SESSION['message']; ?>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById("voteForm").addEventListener("submit", function(event) {
            let now = new Date().getTime();
            if (now >= endTime) {
                event.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Voting has ended',
                    text: 'WAIT FOR THE RESULTS TO BE ANNOUNCED'
                });
            }
        });
  
  
        // Show the message modal if there is a message
        <?php if (isset($_SESSION['message'])): ?>
            const messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
            messageModal.show();
            <?php unset($_SESSION['message']); ?> // Clear message after showing
        <?php endif; ?>
    </script>
    
</body>
</html>
