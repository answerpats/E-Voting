
        // JavaScript to toggle the Add Admin section
        const toggleAddAdmin = document.getElementById('toggleAddAdmin');
        const addAdminSection = document.getElementById('addAdminSection');
        const overlay = document.getElementById('overlay');
        const mainContent = document.querySelector('.container');
        const addAdminButton = document.getElementById('addAdminButton');
        const cancelButton = document.getElementById('cancelButton');

        // Show Add Admin form and blur the background
        toggleAddAdmin.addEventListener('click', function () {
            addAdminSection.style.display = 'block';
            overlay.style.display = 'block';
            mainContent.classList.add('blur');
        });

        // Hide Add Admin form and remove blur effect
        function hideAddAdminForm() {
            addAdminSection.style.display = 'none';
            overlay.style.display = 'none';
            mainContent.classList.remove('blur');
        }

        // Hide form when "Add" button is clicked
        addAdminButton.addEventListener('click', function () {
            hideAddAdminForm();
        });

        // Hide form when "Cancel" button is clicked
        cancelButton.addEventListener('click', function () {
            hideAddAdminForm();
        });

        // Show success message modal if message is set in the session
        window.onload = function() {
            let endTimeString = "<?php echo $votingEndTime; ?>";
            console.log("End time:", endTimeString); // Debugging in browser console
    
            if (!endTimeString) {
                document.getElementById("countdown").innerHTML = "No voting time set.";
                return;
            }
    
            let endTime = new Date(endTimeString).getTime();
            let countdownElement = document.getElementById("countdown");
            let voteForm = document.getElementById("voteForm");
            let voteButton = document.getElementById("voteButton");
    
            function checkVotingEnd() {
                let now = new Date().getTime();
                let timeLeft = endTime - now;
    
                if (timeLeft <= 0) {
                    clearInterval(timer);
    
                    // Show popup
                    Swal.fire({
                        icon: 'error',
                        title: 'Voting has ended!',
                        text: 'WAIT FOR THE RESULTS TO BE ANNOUNCED',
                        confirmButtonText: 'OK'
                    });
    
                    countdownElement.innerHTML = "Voting has ended!";
                    if (voteButton) voteButton.disabled = true; // Disable the vote button if it exists
                    return;
                }
                 
                let days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
                let hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
    
                countdownElement.innerHTML = `${days}d ${hours}h ${minutes}m ${seconds}s `;
            }
    
            let timer = setInterval(checkVotingEnd, 1000);
    
            if (voteForm) {
                voteForm.addEventListener("submit", function(event) {
                    let now = new Date().getTime();
                    if (now >= endTime) {
                        event.preventDefault(); // Prevent form submission
                        Swal.fire({
                            icon: 'error',
                            title: 'Voting has ended!',
                            text: 'WAIT FOR THE RESULTS TO BE ANNOUNCED',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            }
    
            // Check immediately on page load
            checkVotingEnd();
        };
        document.getElementById("voteForm").addEventListener("submit", function(event) {
            let now = new Date().getTime();
            if (now >= endTime) {
                event.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Voting has ended',
                    text: 'WAIT FOR THE RESULTS TO BE ANNOUNCED'
                });
            }
        });
  