<?php
require_once '../database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $candidate_id = $_POST['candidate_id'];

    // Get current time and voting end time
    $current_time = date("Y-m-d H:i:s");
    $query = "SELECT end_time FROM voting_timer ORDER BY id DESC LIMIT 1";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    $votingEndTime = $row['end_time'] ?? '';

    // If voting has ended, stop processing
    if ($current_time >= $votingEndTime) {
        echo json_encode(["status" => "error", "message" => "❌ Voting Period is Over!"]);
        exit;
    }

    // Insert the vote (Assuming you have a votes table)
    $stmt = $conn->prepare("INSERT INTO votes (participant_id) VALUES (?)");
    $stmt->bind_param("i", $candidate_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Vote cast successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error casting vote."]);
    }

    $stmt->close();
}
?>
