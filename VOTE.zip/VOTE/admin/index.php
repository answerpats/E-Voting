<?php
session_start();
require_once '../database.php'; // Include database connection

// Check if participants are already stored in the session
if (!isset($_SESSION['participants'])) {
    $_SESSION['participants'] = [];
}

// Check if form is submitted for adding a participant
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name'])) {
    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO participants (name, role, image, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $role, $image, $description);

    // Set parameters and execute
    $name = $_POST['name'];
    $role = $_POST['role'];
    $description = $_POST['description']; 
    $image = $_FILES['image']['name'];

    // Move uploaded file to a designated folder
    move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $_FILES['image']['name']);
    
    if ($stmt->execute()) {
        // Add participant to the session
        $_SESSION['participants'][] = [
            'name' => $name,
            'role' => $role,
            'description' => $description,
            'image' => $image
        ];
        // Set success message
        $_SESSION['message'] = "You have successfully added a new participant.";
    }

    $stmt->close();
}

// Check if form is submitted for adding an admin
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username'])) {
    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password);

    // Set parameters and execute
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security

    if ($stmt->execute()) {
        // Set success message
        $_SESSION['message'] = "You have successfully added a new admin.";
    }

    $stmt->close();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['end_time'])) {
    $endTime = $_POST['end_time'];

    // Check if a timer already exists
    $query = "SELECT id FROM voting_timer LIMIT 1";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // Update the existing timer
        $query = "UPDATE voting_timer SET end_time = ? WHERE id = (SELECT id FROM voting_timer LIMIT 1)";
    } else {
        // Insert a new timer
        $query = "INSERT INTO voting_timer (end_time) VALUES (?)";
    }

    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $endTime);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Voting timer set successfully!";
    }
}

// Fetch current voting end time
$query = "SELECT end_time FROM voting_timer ORDER BY id DESC LIMIT 1";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$votingEndTime = $row['end_time'] ?? '';
?>

<?php


// Fetch votes and participant data
$query = "
SELECT 
    p.name AS participant_name, 
    COALESCE(v.category, 'Unknown') AS category, 
    COUNT(v.participant_id) AS total_votes
FROM votes v
JOIN participants p ON v.participant_id = p.participant_id
GROUP BY p.name, v.category
ORDER BY total_votes DESC
";

$result = $conn->query($query);

// Debugging: Ensure query executed properly
if (!$result) {
    die("SQL Error: " . $conn->error);
}

// Check if there are results
if ($result->num_rows === 0) {
    $noVotesMessage = "<p style='color:red; text-align:center;'>No votes found. Ensure votes are cast.</p>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <!-- University Logo -->
        <a class="navbar-brand" href="#">
            <img src="image/logo.png" alt="Bugema University Logo" width="50" height="50" class="d-inline-block align-top">
            BUGEMA UNIVERSITY
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-center">
            <span class="navbar-text text-white fw-bold">
                An Adventist Chartered University
            </span>
        </div>
    </div>
</nav>

    <style>
        /* Initially hide the Add Admin section */
        #addAdminSection {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        /* Blur effect for the rest of the content */
        .blur {
            filter: blur(5px);
            pointer-events: none; /* Disable interactions with blurred content */
        }

        /* Overlay background when Add Admin is active */
        #overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <!-- Dropdown for Admin Actions -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Admin Actions
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminDropdown">
                            <li><a class="dropdown-item" href="#" id="toggleAddAdmin">Add New Admin</a></li>
                        </ul>
                    </li>
                    <!-- Logout Button -->
                    <li class="nav-item">
                        <a class="nav-link btn btn-danger text-white ms-2" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
    <h2>Set Voting Timer</h2>
    <form action="index.php" method="POST">
        <div class="mb-3">
            <label for="end_time" class="form-label">Voting End Time</label>
            <input type="datetime-local" class="form-control" id="end_time" name="end_time" required value="<?php echo $votingEndTime; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Set Timer</button>
    </form>
</div>

    <!-- Overlay for blur effect -->
    <div id="overlay"></div>

    <!-- Main Content -->
    <div class="container mt-5">
        <h1 class="text-center">Admin Dashboard</h1>

        <!-- Add Participant Section -->
        <div id="addParticipantSection" class="card mt-4">
            <div class="card-header bg-primary text-white">
                Add Participant
            </div>
            <div class="card-body">
                <form action="index.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="" disabled selected>Select a role</option>
                            <option value="GUILD PRESIDENT">GUILD PRESIDENT</option>
                            <option value="GENERAL SECRETARY">GENERAL SECRETARY</option>
                            <option value="MEMBER OF PARLIAMENT">MEMBER OF PARLIAMENT</option>
                        </select>
                    </div>
                    <div class="mb-3">
                             <label for="description" class="form-label">Description</label>
                             <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label">Upload Image</label>
                        <input type="file" class="form-control" id="image" name="image" required>
                    </div>
                    <button type="submit" class="btn btn-success">Add Participant</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Add Admin Section (Modal-like behavior) -->
    <div id="addAdminSection">
        <h3 class="text-center">Add New Admin</h3>
        <form action="index.php" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
       
            
            <button type="submit" class="btn btn-primary" id="addAdminButton">Add</button>
            <button type="button" class="btn btn-secondary" id="cancelButton">Cancel</button>
        </form>
    </div>

    <!-- Success Message Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Success</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if (isset($_SESSION['message'])): ?>
                        <?php echo $_SESSION['message']; ?>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container mt-5">
        <h1 class="text-center">Participant Votes Summary</h1>

        <?php if (isset($noVotesMessage)) echo $noVotesMessage; ?>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Participant Name</th>
                    <th>Category</th>
                    <th>Total Votes</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['participant_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                        <td><?php echo $row['total_votes']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
  

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript to toggle the Add Admin section
        const toggleAddAdmin = document.getElementById('toggleAddAdmin');
        const addAdminSection = document.getElementById('addAdminSection');
        const overlay = document.getElementById('overlay');
        const mainContent = document.querySelector('.container');
        const addAdminButton = document.getElementById('addAdminButton');
        const cancelButton = document.getElementById('cancelButton');

        // Show Add Admin form and blur the background
        toggleAddAdmin.addEventListener('click', function () {
            addAdminSection.style.display = 'block';
            overlay.style.display = 'block';
            mainContent.classList.add('blur');
        });

        // Hide Add Admin form and remove blur effect
        function hideAddAdminForm() {
            addAdminSection.style.display = 'none';
            overlay.style.display = 'none';
            mainContent.classList.remove('blur');
        }

        // Hide form when "Add" button is clicked
        addAdminButton.addEventListener('click', function () {
            hideAddAdminForm();
        });

        // Hide form when "Cancel" button is clicked
        cancelButton.addEventListener('click', function () {
            hideAddAdminForm();
        });

        // Show success message modal if message is set in the session
        <?php if (isset($_SESSION['message'])): ?>
            const successModal = new bootstrap.Modal(document.getElementById('successModal'));
            successModal.show();
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
    </script>
        <!-- Footer Section -->
        <footer class="footer">
        <div class="container">
            <p class="mb-0">ALL RIGHTS RESERVED &copy; <?php echo date("Y"); ?></p>
        </div>
    </footer>
</body>
</html>