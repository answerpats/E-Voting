<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Voting System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="function.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            color: #0d6efd;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container {
            margin-top: 50px;
            flex: 1;
        }
        .card {
            border-color: #0d6efd;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
        .small-navbar {
        padding: 0px 0; /* Reduces the height */
        font-size: 1.2rem; /* Adjusts text size */
    }
    .university-title {
        font-size: 1.8rem; /* Increases size of "BUGEMA UNIVERSITY" */
    }

    .university-subtitle {
        font-size: 1.2rem; /* Increases size of "Excellence in Service" */
    }
    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container d-flex justify-content-center align-items-center">
        <a class="navbar-brand d-flex align-items-center" href="#">
            <img src="image/logo.png" alt="Bugema University Logo" width="100" height="100" class="me-3 rounded-circle">
            <div class="d-flex flex-column text-center">
                <span class="fw-bold text-white university-title">BUGEMA UNIVERSITY</span>
                <span class="text-white fst-italic university-subtitle">Excellence in Service</span>
            </div>
        </a>
    </div>
</nav>

<nav class="navbar navbar-expand-lg navbar-dark bg-secondary small-navbar">
    <div class="container d-flex justify-content-center">
        <span class="navbar-text text-white fw-bold">
            WELCOME TO BUGEMA UNIVERSITY VOTING SYSTEM
        </span>
    </div>
</nav>


    <!-- Login Options -->
    <div class="container text-center">
     
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card p-4">
                    <h3 class="mb-3">Login as</h3>
                    <button type="button" class="btn btn-primary w-100 mb-3" onclick="window.location.href='user/loginStudent.php'">Student</button>
                    <button type="button" class="btn btn-primary w-100" onclick="window.location.href='admin/loginAdmin.php'">Admin</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="container">
            <p class="mb-0">ALL RIGHTS RESERVED &copy; <?php echo date("Y"); ?></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
