<?php
session_start();

// Ensure the session variable is set
if (!isset($_SESSION['voting_link'])) {
    echo "<script>alert('No voting link found. Please login again.'); window.location.href='loginStudent.php';</script>";
    exit();
}

$voting_link = $_SESSION['voting_link'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Voting Link</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5 text-center">
        <h2>Voting Link</h2>
        <p>We have generated a voting link for you. Click the button below to proceed:</p>
        <a href="<?php echo $voting_link; ?>" class="btn btn-success">Go to Voting Page</a>
    </div>
</body>
</html>
