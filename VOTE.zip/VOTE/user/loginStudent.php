<?php
session_start();
require_once '../database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $registration_number = $_POST['registration_number'];

    // Check if the email has already voted
    $check_query = "SELECT * FROM voters WHERE email = '$email' AND token_used = 1";
    $check_result = mysqli_query($conn, $check_query);

    if (!$check_result) {
        die("Error in SQL query: " . mysqli_error($conn)); // Debugging error
    }

    if (mysqli_num_rows($check_result) > 0) {
        echo "<script>alert('You have already voted. You cannot vote again.'); window.location.href='loginStudent.php';</script>";
        exit();
    }

    // Read the JSON file
    $json_data = file_get_contents('students.json');
    $students = json_decode($json_data, true);

    $is_valid = false;
    foreach ($students['students'] as $student) {
        if ($student['registration_number'] === $registration_number) {
            $is_valid = true;
            break;
        }
    }

    if ($is_valid) {
        // Check if email has already received a voting link
        $link_query = "SELECT voting_link FROM voters WHERE email = '$email' AND token_used = 0";
        $link_result = mysqli_query($conn, $link_query);

        if (!$link_result) {
            die("Error in SQL query: " . mysqli_error($conn)); // Debugging error
        }

        $row = mysqli_fetch_assoc($link_result);

        if ($row) {
            $voting_link = $row['voting_link']; // Reuse existing voting link
        } else {
            // Generate new voting link
            $token = bin2hex(random_bytes(16)); // Generate a secure random token
            $expiry_time = date("Y-m-d H:i:s", strtotime("+1 minutes")); // Expiry time for the link
            $voting_link = "http://localhost/VOTE/user/vote.php?token=$token"; // Update this for hosted site

            // Store new voting link in database
            $sql = "INSERT INTO voters (email, registration_number, voting_token, voting_link, token_used, token_expiry) 
                    VALUES ('$email', '$registration_number', '$token', '$voting_link', 0, '$expiry_time')";

            if (!mysqli_query($conn, $sql)) {
                die("Database Insert Error: " . mysqli_error($conn)); // Debugging error
            }
        }
        // Store voting link in session
        $_SESSION['voting_link'] = $voting_link;

        // Redirect to displayLink.php
        echo "<script>
                alert('We have generated a voting link for you. Click OK to proceed.');
                window.location.href = 'displayLink.php';
              </script>";
        exit();
    } else {
        echo "<script>alert('Invalid registration number!'); window.location.href='loginStudent.php';</script>";
        exit();
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Ensure footer is at the bottom */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .content {
            flex: 1;
        }
        .footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
        .navbar {
    padding: 10px 0;
}

.navbar-brand img {
    border-radius: 5px;
}

.navbar-brand div {
    display: flex;
    flex-direction: column;
    align-items: start;
}

    </style>
    
</head>
<body>

    <!-- Blue Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container d-flex justify-content-center">
        <!-- Logo + Text -->
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="../image/logo.png" alt="Bugema University Logo" width="60" height="60" class="me-2" style="border-radius: 5px;">
            <div class="d-flex flex-column">
                <span class="fw-bold text-white fs-4">BUGEMA UNIVERSITY</span>
                <span class="small text-white fst-italic" style="font-size: 14px;">Excellence in Service</span>
            </div>
        </a>
    </div>

    <!-- Navbar Toggler for Mobile -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navigation Links -->
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active text-white" href="../login.php">Home</a>
            </li>
        </ul>
    </div>
</nav>


<div class="container content mt-5">
    <h2 class="text-center">Student Login</h2>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="registration_number" class="form-label">Registration Number</label>
                        <input type="text" class="form-control" id="registration_number" name="registration_number" required>
                    </div>

                    <!-- Show More Section -->
                    <div class="mt-4">
                        <h3>How the System Works</h3>
                        <p id="moreInfo" style="display: none;">
                            This system allows students to vote securely online. After logging in, students can receive a unique voting link via email. The link is valid for a limited time, ensuring that each student can only vote once. The voting process is designed to be user-friendly and efficient, promoting active participation in university governance.
                        </p>
                        <button id="showMoreBtn" class="btn btn-secondary">Show More</button>
                    </div>

                    <div class="mb-3">
                        <label for="terms" class="form-label">Terms and Conditions</label>
                        <div class="form-text">
                            By using this system, you agree to abide by the university's policies and regulations. Any misuse of the system may result in disciplinary action.
                        </div>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                            <label class="form-check-label" for="terms">I agree to the terms and conditions</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('showMoreBtn').addEventListener('click', function() {
            var moreInfo = document.getElementById('moreInfo');
            if (moreInfo.style.display === 'none') {
                moreInfo.style.display = 'block';
                this.textContent = 'Show Less';
            } else {
                moreInfo.style.display = 'none';
                this.textContent = 'Show More';
            }
        });
    </script>
</div>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="container">
            <p class="mb-0">ALL RIGHTS RESERVED &copy; <?php echo date("Y"); ?></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
